---
description: >-
  A collection of techniques that exploit and abuse Active Directory, Kerberos
  authentication, Domain Controllers and similar matters.
---

# Active Directory & Kerberos Abuse

